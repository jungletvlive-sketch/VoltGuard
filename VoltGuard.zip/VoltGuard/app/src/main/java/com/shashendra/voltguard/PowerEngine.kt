package com.shashendra.voltguard

import android.Manifest
import android.content.ContentResolver
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

/**
 * Applies power profiles.
 *
 * Works with the "Modify system settings" permission: brightness, auto-brightness,
 * screen timeout, haptics, touch sounds, background sync.
 *
 * Extra abilities when WRITE_SECURE_SETTINGS is granted once over ADB:
 * system battery saver, animation scales, mobile-data switch.
 * Rooted phones can also toggle data via `svc data`.
 */
class PowerEngine(private val ctx: Context) {
    private val cr: ContentResolver get() = ctx.contentResolver
    private val prefs = Prefs(ctx)

    fun canWrite(): Boolean = Settings.System.canWrite(ctx)

    fun hasSecure(): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED

    fun apply(mode: Mode) {
        prefs.mode = mode.key
        if (mode == Mode.NORMAL) restore() else {
            snapshot()
            applyMode(mode)
        }
        MonitorService.sync(ctx)
    }

    private fun snapshot() {
        if (prefs.snapshotTaken) return
        try {
            prefs.snapBrightness = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
            prefs.snapBrightnessMode =
                Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 1)
            prefs.snapTimeout = Settings.System.getInt(cr, Settings.System.SCREEN_OFF_TIMEOUT, 60000)
            prefs.snapHaptic = Settings.System.getInt(cr, Settings.System.HAPTIC_FEEDBACK_ENABLED, 1)
            prefs.snapSound = Settings.System.getInt(cr, Settings.System.SOUND_EFFECTS_ENABLED, 1)
            prefs.snapSync = ContentResolver.getMasterSyncAutomatically()
            prefs.snapAnim = Settings.Global.getFloat(cr, Settings.Global.WINDOW_ANIMATION_SCALE, 1f)
            prefs.snapshotTaken = true
        } catch (_: Exception) {
        }
    }

    private fun applyMode(m: Mode) {
        if (canWrite()) {
            try {
                Settings.System.putInt(
                    cr, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                )
                val b = (255 * m.brightnessPct / 100).coerceAtLeast(10)
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, b)
                Settings.System.putInt(cr, Settings.System.SCREEN_OFF_TIMEOUT, m.timeoutMs)
                if (m.minimal) {
                    Settings.System.putInt(cr, Settings.System.HAPTIC_FEEDBACK_ENABLED, 0)
                    Settings.System.putInt(cr, Settings.System.SOUND_EFFECTS_ENABLED, 0)
                }
            } catch (_: Exception) {
            }
        }
        try {
            ContentResolver.setMasterSyncAutomatically(!m.pauseSync)
        } catch (_: Exception) {
        }
        if (hasSecure()) {
            setAnimScale(m.animScale)
            setSystemSaver(m.systemSaver)
        }
    }

    private fun restore() {
        if (!prefs.snapshotTaken) return
        if (canWrite()) {
            try {
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, prefs.snapBrightness)
                Settings.System.putInt(
                    cr, Settings.System.SCREEN_BRIGHTNESS_MODE, prefs.snapBrightnessMode
                )
                Settings.System.putInt(cr, Settings.System.SCREEN_OFF_TIMEOUT, prefs.snapTimeout)
                Settings.System.putInt(cr, Settings.System.HAPTIC_FEEDBACK_ENABLED, prefs.snapHaptic)
                Settings.System.putInt(cr, Settings.System.SOUND_EFFECTS_ENABLED, prefs.snapSound)
            } catch (_: Exception) {
            }
        }
        try {
            ContentResolver.setMasterSyncAutomatically(prefs.snapSync)
        } catch (_: Exception) {
        }
        if (hasSecure()) {
            setAnimScale(prefs.snapAnim)
            setSystemSaver(false)
        }
        prefs.snapshotTaken = false
    }

    private fun setAnimScale(v: Float) {
        try {
            Settings.Global.putFloat(cr, Settings.Global.WINDOW_ANIMATION_SCALE, v)
            Settings.Global.putFloat(cr, Settings.Global.TRANSITION_ANIMATION_SCALE, v)
            Settings.Global.putFloat(cr, Settings.Global.ANIMATOR_DURATION_SCALE, v)
        } catch (_: Exception) {
        }
    }

    private fun setSystemSaver(on: Boolean) {
        try {
            Settings.Global.putInt(cr, "low_power", if (on) 1 else 0)
        } catch (_: Exception) {
        }
    }

    // ---- Mobile data (needs ADB-granted secure access, or root) ----

    private fun isDataOn(): Boolean =
        try {
            Settings.Global.getInt(cr, "mobile_data", 1) == 1
        } catch (_: Exception) {
            true
        }

    fun cutData() {
        if (prefs.dataCutByUs || !isDataOn()) return
        prefs.dataCutByUs = true
        setData(false)
    }

    fun restoreData() {
        if (!prefs.dataCutByUs) return
        prefs.dataCutByUs = false
        setData(true)
    }

    private fun setData(on: Boolean) {
        if (hasSecure()) {
            try {
                Settings.Global.putInt(cr, "mobile_data", if (on) 1 else 0)
            } catch (_: Exception) {
            }
        }
        Thread {
            try {
                val cmd = if (on) "svc data enable" else "svc data disable"
                Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).waitFor()
            } catch (_: Exception) {
                // phone is not rooted - ignore
            }
        }.start()
    }
}
