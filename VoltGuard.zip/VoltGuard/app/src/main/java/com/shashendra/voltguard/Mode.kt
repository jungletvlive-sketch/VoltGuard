package com.shashendra.voltguard

/** Power profiles. extraPct is an estimate of extra battery life, not a guarantee. */
enum class Mode(
    val key: Int,
    val title: String,
    val subtitle: String,
    val brightnessPct: Int,
    val timeoutMs: Int,
    val animScale: Float,
    val pauseSync: Boolean,
    val minimal: Boolean,
    val systemSaver: Boolean,
    val extraPct: Int,
    val color: Int
) {
    NORMAL(0, "Normal", "Your own settings, untouched", -1, -1, 1f, false, false, false, 0, 0xFF8FA6C4.toInt()),
    SMART(1, "Smart Saver", "Dimmer screen, shorter timeout", 45, 30000, 1f, false, false, false, 20, 0xFF00FF9C.toInt()),
    SUPER(2, "Super Saver", "Strong savings, stay productive", 25, 15000, 0.5f, true, false, true, 50, 0xFF00E5FF.toInt()),
    ULTRA(3, "Ultra Power", "Maximum battery, essentials only", 8, 15000, 0f, true, true, true, 100, 0xFFA97CFF.toInt());

    companion object {
        fun fromKey(k: Int): Mode = values().firstOrNull { it.key == k } ?: NORMAL
    }
}
