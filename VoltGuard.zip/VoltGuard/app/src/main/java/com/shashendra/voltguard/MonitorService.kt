package com.shashendra.voltguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class MonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var engine: PowerEngine
    private lateinit var prefs: Prefs
    private var registered = false
    private var lastPct = -1

    private val cutRunnable = Runnable {
        if (prefs.dataCutEnabled) engine.cutData()
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    if (prefs.dataCutEnabled) {
                        handler.removeCallbacks(cutRunnable)
                        handler.postDelayed(cutRunnable, prefs.dataCutDelaySec * 1000L)
                    }
                }
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                    handler.removeCallbacks(cutRunnable)
                    engine.restoreData()
                }
                Intent.ACTION_BATTERY_CHANGED -> onBattery(i)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        engine = PowerEngine(this)
        prefs = Prefs(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        if (!registered) {
            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_USER_PRESENT)
                addAction(Intent.ACTION_BATTERY_CHANGED)
            }
            ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
            registered = true
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(cutRunnable)
        engine.restoreData()
        if (registered) {
            try {
                unregisterReceiver(receiver)
            } catch (_: Exception) {
            }
            registered = false
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun onBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level < 0 || scale <= 0) return
        val pct = level * 100 / scale
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        if (prefs.autoSmart) {
            if (!charging && pct <= prefs.autoThreshold &&
                prefs.mode == Mode.NORMAL.key && !prefs.autoApplied
            ) {
                prefs.autoApplied = true
                engine.apply(Mode.SMART)
            } else if (charging && prefs.autoApplied) {
                prefs.autoApplied = false
                engine.apply(Mode.NORMAL)
            }
        }
        if (pct != lastPct) {
            lastPct = pct
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        }
    }

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL, "VoltGuard status", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val mode = Mode.fromKey(prefs.mode)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("VoltGuard is protecting your battery")
            .setContentText("Mode: ${mode.title}")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        private const val CHANNEL = "voltguard_status"
        private const val NOTIF_ID = 4021

        fun sync(ctx: Context) {
            val i = Intent(ctx, MonitorService::class.java)
            if (Prefs(ctx).needsService()) {
                try {
                    ContextCompat.startForegroundService(ctx, i)
                } catch (_: Exception) {
                }
            } else {
                ctx.stopService(i)
            }
        }
    }
}
