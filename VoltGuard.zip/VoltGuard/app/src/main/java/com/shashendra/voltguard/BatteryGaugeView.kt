package com.shashendra.voltguard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

/** Circular battery gauge with a neon gradient arc. */
class BatteryGaugeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var level: Int = 0
        set(value) {
            field = value.coerceIn(0, 100)
            invalidate()
        }

    var subtitle: String = ""
        set(value) {
            field = value
            invalidate()
        }

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = 0xFF16294A.toInt()
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFEAF4FF.toInt()
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF8FA6C4.toInt()
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(canvas: Canvas) {
        val size = min(width, height).toFloat()
        val sw = size * 0.075f
        track.strokeWidth = sw
        arc.strokeWidth = sw
        glow.strokeWidth = sw * 1.8f
        val cx = width / 2f
        val cy = height / 2f
        val r = size / 2f - sw * 1.2f
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)

        canvas.drawArc(rect, 135f, 270f, false, track)

        val sweep = 270f * level / 100f
        if (sweep > 0f) {
            val c1: Int
            val c2: Int
            when {
                level <= 15 -> { c1 = 0xFFFF4D6D.toInt(); c2 = 0xFFFFB300.toInt() }
                level <= 30 -> { c1 = 0xFFFFB300.toInt(); c2 = 0xFF00FF9C.toInt() }
                else -> { c1 = 0xFF00E5FF.toInt(); c2 = 0xFF00FF9C.toInt() }
            }
            canvas.save()
            canvas.rotate(135f, cx, cy)
            arc.shader = SweepGradient(
                cx, cy, intArrayOf(c1, c2, c2), floatArrayOf(0f, 0.75f, 1f)
            )
            glow.color = c2
            glow.alpha = 50
            canvas.drawArc(rect, 0f, sweep, false, glow)
            canvas.drawArc(rect, 0f, sweep, false, arc)
            canvas.restore()
        }

        big.textSize = size * 0.22f
        small.textSize = size * 0.06f
        canvas.drawText("$level%", cx, cy + big.textSize * 0.2f, big)
        canvas.drawText(subtitle, cx, cy + size * 0.22f, small)
    }
}
