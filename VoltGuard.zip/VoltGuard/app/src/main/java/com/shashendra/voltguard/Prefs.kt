package com.shashendra.voltguard

import android.content.Context
import android.content.SharedPreferences

class Prefs(ctx: Context) {
    private val sp: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("voltguard", Context.MODE_PRIVATE)

    var mode: Int
        get() = sp.getInt("mode", 0)
        set(v) { sp.edit().putInt("mode", v).apply() }

    var dataCutEnabled: Boolean
        get() = sp.getBoolean("dataCut", false)
        set(v) { sp.edit().putBoolean("dataCut", v).apply() }

    var dataCutDelaySec: Int
        get() = sp.getInt("dataCutDelay", 10)
        set(v) { sp.edit().putInt("dataCutDelay", v).apply() }

    var dataCutByUs: Boolean
        get() = sp.getBoolean("dataCutByUs", false)
        set(v) { sp.edit().putBoolean("dataCutByUs", v).apply() }

    var autoSmart: Boolean
        get() = sp.getBoolean("autoSmart", false)
        set(v) { sp.edit().putBoolean("autoSmart", v).apply() }

    var autoThreshold: Int
        get() = sp.getInt("autoThreshold", 20)
        set(v) { sp.edit().putInt("autoThreshold", v).apply() }

    var autoApplied: Boolean
        get() = sp.getBoolean("autoApplied", false)
        set(v) { sp.edit().putBoolean("autoApplied", v).apply() }

    // Snapshot of the user's original settings, restored when going back to Normal
    var snapshotTaken: Boolean
        get() = sp.getBoolean("snapTaken", false)
        set(v) { sp.edit().putBoolean("snapTaken", v).apply() }

    var snapBrightness: Int
        get() = sp.getInt("snapBrightness", 128)
        set(v) { sp.edit().putInt("snapBrightness", v).apply() }

    var snapBrightnessMode: Int
        get() = sp.getInt("snapBrightnessMode", 1)
        set(v) { sp.edit().putInt("snapBrightnessMode", v).apply() }

    var snapTimeout: Int
        get() = sp.getInt("snapTimeout", 60000)
        set(v) { sp.edit().putInt("snapTimeout", v).apply() }

    var snapHaptic: Int
        get() = sp.getInt("snapHaptic", 1)
        set(v) { sp.edit().putInt("snapHaptic", v).apply() }

    var snapSound: Int
        get() = sp.getInt("snapSound", 1)
        set(v) { sp.edit().putInt("snapSound", v).apply() }

    var snapSync: Boolean
        get() = sp.getBoolean("snapSync", true)
        set(v) { sp.edit().putBoolean("snapSync", v).apply() }

    var snapAnim: Float
        get() = sp.getFloat("snapAnim", 1f)
        set(v) { sp.edit().putFloat("snapAnim", v).apply() }

    fun needsService(): Boolean = mode != Mode.NORMAL.key || dataCutEnabled || autoSmart
}
