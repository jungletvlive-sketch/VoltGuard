package com.shashendra.voltguard

import android.Manifest
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var engine: PowerEngine
    private lateinit var gauge: BatteryGaugeView
    private lateinit var tvTemp: TextView
    private lateinit var tvVolt: TextView
    private lateinit var tvHealth: TextView
    private lateinit var tvEstimate: TextView
    private lateinit var tvThreshold: TextView
    private lateinit var tvWriteStatus: TextView
    private lateinit var tvNotifStatus: TextView
    private lateinit var tvAdvStatus: TextView
    private lateinit var btnWrite: TextView
    private lateinit var btnNotif: TextView
    private lateinit var btnAdv: TextView

    private val modeViews = LinkedHashMap<Mode, View>()

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refreshAccess() }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            updateBattery(i)
            updateModeUi()
        }
    }

    private val adbCommand =
        "adb shell pm grant com.shashendra.voltguard android.permission.WRITE_SECURE_SETTINGS"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)
        engine = PowerEngine(this)

        gauge = findViewById(R.id.gauge)
        tvTemp = findViewById(R.id.tvTemp)
        tvVolt = findViewById(R.id.tvVolt)
        tvHealth = findViewById(R.id.tvHealth)
        tvEstimate = findViewById(R.id.tvEstimate)
        tvThreshold = findViewById(R.id.tvThreshold)
        tvWriteStatus = findViewById(R.id.tvWriteStatus)
        tvNotifStatus = findViewById(R.id.tvNotifStatus)
        tvAdvStatus = findViewById(R.id.tvAdvStatus)
        btnWrite = findViewById(R.id.btnWrite)
        btnNotif = findViewById(R.id.btnNotif)
        btnAdv = findViewById(R.id.btnAdv)

        buildModeCards()
        setupAutomation()
        setupQuickControls()

        btnWrite.setOnClickListener { openWriteSettings() }
        btnNotif.setOnClickListener { requestNotifPermission() }
        btnAdv.setOnClickListener { showAdvancedDialog() }

        requestNotifPermission()
    }

    override fun onResume() {
        super.onResume()
        refreshAccess()
        updateModeUi()
        val sticky = registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (sticky != null) updateBattery(sticky)
    }

    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(batteryReceiver)
        } catch (_: Exception) {
        }
    }

    // ---------- Modes ----------

    private fun buildModeCards() {
        val container = findViewById<android.widget.LinearLayout>(R.id.modeContainer)
        val inflater = LayoutInflater.from(this)
        val icons = mapOf(
            Mode.NORMAL to R.drawable.ic_power,
            Mode.SMART to R.drawable.ic_eco,
            Mode.SUPER to R.drawable.ic_battery,
            Mode.ULTRA to R.drawable.ic_bolt
        )
        for (m in Mode.values()) {
            val v = inflater.inflate(R.layout.item_mode, container, false)
            v.findViewById<TextView>(R.id.tvTitle).text = m.title
            v.findViewById<TextView>(R.id.tvSub).text = m.subtitle
            val iv = v.findViewById<ImageView>(R.id.ivIcon)
            iv.setImageResource(icons.getValue(m))
            iv.setColorFilter(m.color)
            v.setOnClickListener { selectMode(m) }
            container.addView(v)
            modeViews[m] = v
        }
    }

    private fun selectMode(m: Mode) {
        if (m != Mode.NORMAL && !engine.canWrite()) {
            showWriteDialog()
            return
        }
        prefs.autoApplied = false
        engine.apply(m)
        updateModeUi()
        Toast.makeText(this, m.title + " activated", Toast.LENGTH_SHORT).show()
    }

    private fun updateModeUi() {
        val current = Mode.fromKey(prefs.mode)
        for ((m, v) in modeViews) {
            val selected = m == current
            v.setBackgroundResource(if (selected) R.drawable.bg_card_selected else R.drawable.bg_card)
            val badge = v.findViewById<TextView>(R.id.tvBadge)
            if (selected) {
                badge.text = "ACTIVE"
                badge.setTextColor(getColor(R.color.vg_green))
            } else {
                badge.text = if (m == Mode.NORMAL) "" else "EST. +" + m.extraPct + "%"
                badge.setTextColor(getColor(R.color.vg_text2))
            }
        }
        tvEstimate.text = if (current == Mode.NORMAL) {
            "Pick a mode to extend battery life. Figures are estimates and vary by phone and usage."
        } else {
            "Estimated battery life gain: about +" + current.extraPct +
                "% vs normal use (varies by phone, signal and apps)."
        }
    }

    // ---------- Automation ----------

    private fun setupAutomation() {
        val swData = findViewById<MaterialSwitch>(R.id.swDataCut)
        val swAuto = findViewById<MaterialSwitch>(R.id.swAutoSmart)
        val seek = findViewById<SeekBar>(R.id.seekThreshold)

        swData.isChecked = prefs.dataCutEnabled
        swAuto.isChecked = prefs.autoSmart
        seek.progress = prefs.autoThreshold - 10
        updateThresholdText(prefs.autoThreshold)

        swData.setOnCheckedChangeListener { _, checked ->
            prefs.dataCutEnabled = checked
            if (!checked) engine.restoreData()
            MonitorService.sync(this)
            if (checked && !engine.hasSecure()) showAdvancedDialog()
        }
        swAuto.setOnCheckedChangeListener { _, checked ->
            prefs.autoSmart = checked
            if (!checked) prefs.autoApplied = false
            MonitorService.sync(this)
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + 10
                prefs.autoThreshold = v
                updateThresholdText(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun updateThresholdText(v: Int) {
        tvThreshold.text = "Switches to Smart Saver at $v% and restores when charging."
    }

    // ---------- Quick controls ----------

    private fun setupQuickControls() {
        findViewById<View>(R.id.btnWifi).setOnClickListener {
            safeStart(
                if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                else Intent(Settings.ACTION_WIFI_SETTINGS)
            )
        }
        findViewById<View>(R.id.btnBluetooth).setOnClickListener {
            safeStart(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }
        findViewById<View>(R.id.btnDisplay).setOnClickListener {
            safeStart(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        }
        findViewById<View>(R.id.btnBattery).setOnClickListener {
            safeStart(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        }
    }

    private fun safeStart(i: Intent) {
        try {
            startActivity(i)
        } catch (_: Exception) {
            Toast.makeText(this, "Not available on this phone", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Battery info ----------

    private fun updateBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level >= 0 && scale > 0) gauge.level = level * 100 / scale
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        gauge.subtitle = if (charging) "CHARGING" else "ON BATTERY"
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        val volt = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) / 1000f
        tvTemp.text = String.format("%.1f°C", temp)
        tvVolt.text = String.format("%.2f V", volt)
        tvHealth.text = when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, 0)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Hot"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Weak"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over-V"
            else -> "Unknown"
        }
    }

    // ---------- Permissions ----------

    private fun refreshAccess() {
        val write = engine.canWrite()
        tvWriteStatus.text = if (write) "Granted" else "Needed for brightness and screen timeout"
        tvWriteStatus.setTextColor(getColor(if (write) R.color.vg_green else R.color.vg_amber))
        btnWrite.visibility = if (write) View.GONE else View.VISIBLE

        val notif = notifGranted()
        tvNotifStatus.text = if (notif) "Allowed" else "Needed to keep protection running"
        tvNotifStatus.setTextColor(getColor(if (notif) R.color.vg_green else R.color.vg_amber))
        btnNotif.visibility = if (notif) View.GONE else View.VISIBLE

        val adv = engine.hasSecure()
        tvAdvStatus.text = if (adv) "Active - data cut, system saver, animations"
        else "Optional - unlocks mobile-data cut and system saver"
        tvAdvStatus.setTextColor(getColor(if (adv) R.color.vg_green else R.color.vg_text2))
        btnAdv.visibility = if (adv) View.GONE else View.VISIBLE
    }

    private fun notifGranted(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestNotifPermission() {
        if (!notifGranted()) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun openWriteSettings() {
        safeStart(
            Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
        )
    }

    private fun showWriteDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Permission needed")
            .setMessage(
                "VoltGuard needs \"Modify system settings\" to change brightness and screen " +
                    "timeout. Tap Grant, then switch it on for VoltGuard."
            )
            .setPositiveButton("Grant") { _, _ -> openWriteSettings() }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun showAdvancedDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Advanced access (one-time)")
            .setMessage(
                "Android does not let normal apps switch mobile data or the system battery " +
                    "saver. To unlock them without root:\n\n" +
                    "1. Turn on Developer options and USB debugging.\n" +
                    "2. Connect the phone to a PC and run:\n\n" + adbCommand + "\n\n" +
                    "Rooted phones work automatically. Without this, all other features " +
                    "still work."
            )
            .setPositiveButton("Copy command") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("adb", adbCommand))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Close", null)
            .show()
    }
}
