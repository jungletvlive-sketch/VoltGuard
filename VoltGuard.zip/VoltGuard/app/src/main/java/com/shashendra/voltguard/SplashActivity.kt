package com.shashendra.voltguard

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val center = findViewById<LinearLayout>(R.id.splashCenter)
        val dev = findViewById<android.view.View>(R.id.splashDev)
        center.alpha = 0f
        center.scaleX = 0.85f
        center.scaleY = 0.85f
        dev.alpha = 0f
        center.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start()
        dev.animate().alpha(1f).setStartDelay(500).setDuration(700).start()

        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }, 2200)
    }
}
