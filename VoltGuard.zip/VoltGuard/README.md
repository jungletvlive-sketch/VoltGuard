# VoltGuard - Smart Power Manager

Developed by Shashendra Nirvan.

Android battery saver app: Normal / Smart / Super / Ultra Power modes, screen-off
mobile-data cut, auto Smart Saver at low battery, live battery gauge, neon tech UI.

## Get the APK (no Android Studio needed)
1. Create a GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab -> **Build APK** -> run it (it also runs on every push).
3. When it finishes, open the run and download the **VoltGuard-APK** artifact.
4. Unzip it and install `app-debug.apk` on your phone.

## First-run setup on the phone
- Grant **Modify system settings** (brightness, screen timeout) and allow notifications.
- Optional, for mobile-data cut and system battery saver, run once from a PC:

      adb shell pm grant com.shashendra.voltguard android.permission.WRITE_SECURE_SETTINGS

## Notes
- Android blocks normal apps from toggling mobile data/Wi-Fi/Bluetooth directly; the quick
  controls open the system panels, and data cut needs the ADB step above (or root).
- "Est. +%" figures are estimates, not guarantees.
